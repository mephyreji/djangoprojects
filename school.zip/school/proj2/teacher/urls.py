from django.urls import path 
from.views import *

urlpatterns=[

    path('add/',AddMarkView.as_view(),name="adm"),
    path('sub/',AddStudentMView.as_view(),name="addstudent"),
    path('view/',ViewStudentView.as_view(),name="viw"),
    path('delstudent/<int:ssid>',StudentDeleteView.as_view(),name="del"),
    path('editstudent/<int:sid>',StudentEditMView.as_view(),name="edit"),



]