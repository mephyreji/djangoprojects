from django.db import models

# Create your models here.
class StudentModel(models.Model):
    first=models.CharField(max_length=100)
    last=models.CharField(max_length=100,null=True)
    age=models.IntegerField()
    address=models.CharField(max_length=100)
    email=models.EmailField(null=True)
    phone=models.IntegerField(null=True)
    image=models.ImageField(upload_to="student_image",null=True)
    
