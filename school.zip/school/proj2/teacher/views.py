from django.shortcuts import render,redirect
from django.views.generic import View
from django.http import HttpResponse
from.forms import AddMarkForm,AddStudentForm,StudentMForm
from django.contrib import messages
from .models import StudentModel
from django.utils.decorators import method_decorator

def signin_required(fun):
    def wrapper(req,*args, **kwargs):
        if req.user.is_authenticated:
            return fun(req,*args, **kwargs)
        else:
           return redirect("logs")
    return wrapper


# Create your views here.
@method_decorator(signin_required,name="dispatch")
class AddMarkView(View):
    def get (self,req,*args, **kwargs):
        f=AddMarkForm()
        return render(req,"addmark.html",{"forms":f})
    def post(self,req,*args, **kwargs): 
        form_data=AddMarkForm(data=req.POST)
        if form_data.is_valid():
            sub1=form_data.cleaned_data.get("n1")
            sub2=form_data.cleaned_data.get("n2")
            sub3=form_data.cleaned_data.get("n3")
            sub4=form_data.cleaned_data.get("n4")
            sub5=form_data.cleaned_data.get("n5")
            res=int(sub1)+int(sub2)+int(sub3)+int(sub4)+int(sub4)
            return render (req,"addmark.html",{"abc":res})
        else:
            return render(req,"addmark.html",{"form":form_data})




@method_decorator(signin_required,name="dispatch")
class ViewStudentView(View):
    def get (self,req,*args, **kwargs):
            res=StudentModel.objects.all()
            return render(req,"viewstudent.html",{"data":res})

@method_decorator(signin_required,name="dispatch")
class StudentDeleteView(View):
    def get (self,req,*args, **kwargs):
        sid=kwargs.get("ssid")
        stu=StudentModel.objects.get(id=sid)
        stu.delete()
        return redirect("viw")

#class StudentEditView(View):
   # def get (self,req,*args, **kwargs):
       # id=sid=kwargs.get("sid")
      #  stu=StudentModel.objects.get(id=sid)

     #   f=AddStudentForm(initial={"first_name":stu.first,"last_name":stu.last,"age":stu.age,"address":stu.address,"email":stu.email,"phone":stu.phone})
    #    return render(req,"editstudent.html",{"form":f})
   # def post(self,req,*args, **kwargs): 
        #form_data=AddStudentForm(data=req.POST)
      #
      # 
      #   if form_data.is_valid():
    #        fn=(form_data.cleaned_data.get("first_name"))
   #         ln=(form_data.cleaned_data.get("last_name"))
  #          age=(form_data.cleaned_data.get("age"))
        #    email=(form_data.cleaned_data.get("email"))
       #     phone=(form_data.cleaned_data.get("phone"))
      #      address=(form_data.cleaned_data.get("address"))
     #       id=kwargs.get("sid")
    #        stu=StudentModel.objects.get(id=id)
   #         stu.last=ln
            #stu.age=age
           # stu.email=email
         #   stu.phone=phone
          #  stu.save()
        #    messages.success(req,"student -details update successfully!! ")
       #     return redirect("viw")
     ##   else:
           # messages.error(req,"update failed!!")
          #  return render(req,"editstudent.html",{"form":form_data})



@method_decorator(signin_required,name="dispatch") 
class StudentEditMView(View):
    def get (self,req,*args, **kwargs):
        id=kwargs.get("sid")
        stu=StudentModel.objects.get(id=id)
        f=StudentMForm(instance=stu)
        return render(req,"editstudent.html",{"form":f})
    def post(self,req,*args, **kwargs):
        id=kwargs.get("sid")
        stu=StudentModel.objects.get(id=id) 
        form_data=StudentMForm(data=req.POST,instance=stu,files=req.FILES)
        if form_data.is_valid():
            form_data.save()
            messages.success(req,"student -details update successfully!! ")
            return redirect("viw")
        else:
            messages.error(req,"update failed!!")
            return render(req,"editstudent.html",{"form":form_data})



    
            

    
        

#class AddStudentView(View):
#    def get (self,req,*args, **kwargs):
    #    f=AddStudentForm()
 #       return render(req,"addstudent.html",{"forms":f})
  #  def post(self,req,*args, **kwargs):
   #     form_data=AddStudentForm(data=req.POST)
        #if form_data.is_valid():
            #fn=(form_data.cleaned_data.get("first_name"))
           # ln=(form_data.cleaned_data.get("last_name"))
          #  age=(form_data.cleaned_data.get("age"))
         #   email=(form_data.cleaned_data.get("email"))
      #      phone=(form_data.cleaned_data.get("phone"))
       #3     address=(form_data.cleaned_data.get("address"))
        #   StudentModel.objects.create(first=fn,last=ln,age=age,phone=phone,email=email,address=address)
     #       messages.success(req,"student added successfully")
    #        return redirect("h")
   #     else:
  #          messages.error(req,"student adding failed!!!!!!")
 #           return render(req,"addstudent.html",{"form":form_data})

@method_decorator(signin_required,name="dispatch")
class AddStudentMView(View):
    def get (self,req,*args, **kwargs):
        f=StudentMForm()
        return render(req,"addstudent.html",{"form":f})
    def post(self,req,*args, **kwargs): 
        form_data=StudentMForm(data=req.POST,files=req.FILES)
        if form_data.is_valid():
            form_data.save()
            messages.success(req,"student -details update successfully!! ")
            return redirect("h")
        else:
            messages.error(req,"update failed!!")
            return render(req,"addstudent.html",{"form":form_data})


        


        
         
