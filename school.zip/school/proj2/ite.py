# class Myclass:
#     name="mephy"
#     @property
#     def fun(self):
#         return"hello"
# ob=Myclass()
# print(ob.name)
#print(ob.fun)

def dec_fun(fun):
    def wrapper(a,b):
        if a>b:
            return fun (a,b)
        else:
            return fun(b,a)
    return wrapper

@dec_fun
def diff(a,b):
    return a-b
@dec_fun
def div(a,b):
    return a/b
print(diff(100,20))
print(div(100,20))

def signin_required(fun):
    def wrapper(self,req,*args, **kwargs):
        if req.user.is_authenticated:
