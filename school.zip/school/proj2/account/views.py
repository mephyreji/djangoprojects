from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.views.generic import View
from.forms import *
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
# Create your views here.
class HomeVeiw(View):
    def get (self,request,*args, **kwargs):
        us=request.user
        return render(request,"main_home.html")
class LogOutView(View):
    def get (self,request,*args, **kwargs):
        logout(request)
        return redirect("logs")
        


class LogVeiw(View):
    def get (self,request,*args, **kwargs):
        f=LogForm()
        us=request.user
        return render(request,"log.html",{"form":f,"user":us})
    def post(self,req,*args, **kwargs):
        form_data=LogForm(data=req.POST)
        if form_data.is_valid():
            un=form_data.cleaned_data.get("uname")
            ps=form_data.cleaned_data.get("pswd")
            user=authenticate(req,username=un,password=ps)
            if user:
                login(req,user)
                messages.success(req,"User login successfully!! ")
                return redirect("h")
            else:
                messages.error(req,"User login failed!!")
                return redirect("logs")
        else:
            return render(req,"login.html",{"form":form_data})

            

# class RegView(View):
#     def get (self,request,*args, **kwargs):
#          return render(request,"reg.html")
#     def post(self,request,*args, **kwargs): 
#         print(request.POST.get("first name"))
#         print(request.POST.get("surname"))
#         print(request.POST.get("email"))
#         print(request.POST.get("uname"))
#         print(request.POST.get("password"))
#         print(request.POST.get("comfirm password")) 
        
#         return HttpResponse("firstname:"+request.POST.get("first name")+"<br>surname"+request.POST.get("surname"))
class RegView(View):
    def get (self,req,*args, **kwargs):
        f=RegForm()
        return render(req,"reg.html",{"form":f})
    def post(self,req,*args, **kwargs): 
        form_data=RegForm(data=req.POST)
        if form_data.is_valid():
            form_data.save()
            messages.success(req,"User Registration successfully!! ")
            return redirect("logs")
        else:
            messages.error(req,"User Registration failed!!")
            return render(req,"reg.html",{"form":form_data})
