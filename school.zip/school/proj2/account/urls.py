
from django.urls import path
from .views import LogOutView,RegView,HomeVeiw 

urlpatterns=[
    path('registration/',RegView. as_view(),name="reg"),
    path('mhome/',HomeVeiw. as_view(),name="h"),
    path('logout/',LogOutView. as_view(),name="logout"),

] 